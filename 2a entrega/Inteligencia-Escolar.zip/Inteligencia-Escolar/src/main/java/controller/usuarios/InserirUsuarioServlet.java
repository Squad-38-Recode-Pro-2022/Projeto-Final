package controller.usuarios;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.usuarios.Usuario;
import model.usuarios.UsuarioDAO;


@WebServlet("/inserir-usuario")
public class InserirUsuarioServlet extends HttpServlet {


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		// recebendo os dados do formulario via parametro
		String nome = request.getParameter("nome");
		String telefone = request.getParameter("telefone");
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");
		String categoria = request.getParameter("categoria");
		String escola = request.getParameter("escola");
		
		
		// criando o objeto usuario 
		Usuario objUsuario =  new Usuario();
		
		// guardando os dados do formulario no objeto
		objUsuario.setNome(nome);
		objUsuario.setTelefone(telefone);
		objUsuario.setEmail(email);
		objUsuario.setSenha(senha);
		objUsuario.setCategoria(categoria);
		objUsuario.setEscola(escola);
		
		// criando um objeto DAO para enviar o objeto Usuario para o banco de dados
		// usando o método save da classe UsuarioDAO
		UsuarioDAO udao = new UsuarioDAO();		
		udao.save(objUsuario);
		
		// Redirecionando o usuario para a pagina de login.
		response.sendRedirect("views/login.html");	
		
	}

}
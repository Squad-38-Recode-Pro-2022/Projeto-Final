package controller.usuarios;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.usuarios.Usuario;
import model.usuarios.UsuarioDAO;

@WebServlet("/crud-usuario")
public class ListaUsuariosServlet extends HttpServlet {


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Usuario> listaUsuarios = new ArrayList<Usuario>();
		UsuarioDAO udao = new UsuarioDAO();		
		listaUsuarios = udao.getUsuarios();		
		req.setAttribute("listaUsuarios", listaUsuarios);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("views/admin/admin-usuario.jsp");
		dispatcher.forward(req, resp);
	}

}

package controller.usuarios;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.usuarios.Usuario;
import model.usuarios.UsuarioDAO;

@WebServlet("/editar-usuario")
public class AlterarUsuarioServlet extends HttpServlet {


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int idUsuario = Integer.parseInt(req.getParameter("id"));
		UsuarioDAO udao = new UsuarioDAO();
		Usuario usuarioSelecionado = udao.getUsuarioById(idUsuario);

		req.setAttribute("usuario", usuarioSelecionado);
	
		RequestDispatcher rd = req.getRequestDispatcher("./views/admin/admin-alterar-usuario.jsp");

        rd.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Usuario usuarioAlterado = new Usuario();		
		usuarioAlterado.setNome(req.getParameter("nome"));
		usuarioAlterado.setTelefone(req.getParameter("telefone"));
		usuarioAlterado.setEmail(req.getParameter("email"));
		usuarioAlterado.setSenha(req.getParameter("senha"));
		usuarioAlterado.setCategoria(req.getParameter("categoria"));
		usuarioAlterado.setEscola(req.getParameter("escola"));
		usuarioAlterado.setId(Integer.parseInt(req.getParameter("id")));
		
		UsuarioDAO ud = new UsuarioDAO();
		ud.update(usuarioAlterado);	
		resp.sendRedirect("crud-usuario");
	}
}